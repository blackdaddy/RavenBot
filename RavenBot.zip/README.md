# RavenBot

## 사용법

1. 블루스택 설치 : http://bit.ly/bstkdnldpage
2. 블루스택에 알아서 Raven 게임 설치
3. Raven bot 설치 : https://github.com/darkdaddy/RavenBot/tree/master/release
4. Start 버튼을 누름
5. 블루스택 화면 사이즈가 안 맞으면 자동으로 맞추고 재시작 해줌.
6. Raven Bot 실행 후, Start 누르면 시작됨.

## 문제 발생시

Screen Shot 버튼을 누르면 /capture/ 폴더에 현재 시간으로 이미지 파일이 저장됨. 그 파일과 logs 폴더에 있는 파일을 압축해서
그 분(?)께 전달해주면 됨.

## Thanks for Clashbot
